/* *
 * CEN 3024C
 * @version Final Project | Word Occurrences
 * @author Raymond Ynoa
 * 
 * The combined project.
 * */

// Imported Java packages.
import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;

// All test suite.
@Suite
@SelectClasses({ showErrorTest.class, urlTest.class })
public class AllTestsAnayzler {

}
